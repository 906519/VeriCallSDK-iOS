//
//  VeriCallOTP.h
//  VeriCallOTP
//
//  Created by Alvin Resmana on 2020/12/5.
//  Copyright © 2020 Alvin.Resmana. All rights reserved.

#import <Foundation/Foundation.h>

//! Project version number for VeriCallOTP.
FOUNDATION_EXPORT double VeriCallOTPVersionNumber;

//! Project version string for VeriCallOTP.
FOUNDATION_EXPORT const unsigned char VeriCallOTPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VeriCallOTP/PublicHeader.h>


